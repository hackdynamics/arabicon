from _arabicon import *
