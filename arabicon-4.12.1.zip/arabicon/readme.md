# ARABICON

ARABICON is an IRC client for Windows and UNIX-like operating systems.  
See [IRCHelp.org](http://irchelp.org) for information about IRC in general.  
For more information on ARABICON please read our [documentation](https://arabicon.readthedocs.org/en/latest/index.html):
- [Downloads](http://arabicon.github.io/downloads.html)
- [FAQ](https://arabicon.readthedocs.org/en/latest/faq.html)
- [Changelog](https://arabicon.readthedocs.org/en/latest/changelog.html)
- [Python API](https://arabicon.readthedocs.org/en/latest/script_python.html)
- [Perl API](https://arabicon.readthedocs.org/en/latest/script_perl.html)

---

<center>
<img src="https://github.com/hackdynamics/arabicon/blob/main/arabicon.png"><br><br>....<br><br>
<img src="https://github.com/hackdynamics/arabicon/blob/main/arabicon-win.png">
</center>
<br>
Build on Linux:<br>
# apt install meson libcanberra-dev libdbus-glib-1-dev libglib2.0-dev libgtk2.0-dev libluajit-5.1-dev libpci-dev libperl-dev libssl-dev python3-dev python3-cffi mono-devel desktop-file-utils<br>
# meson build<br>
# ninja -C build<br>
# ninja -C build install<br>
<br>
<sub> 
X-Chat ("xchat") Copyright (c) 1998-2010 By Peter Zelezny. <br>
HexChat ("hexchat") Copyright (c) 2009-2014 By Berke Viktor.<br>
RUBIRC ("rubirc") Copyright (c) 2023-2026 By  Alexey Kuleshov.<br>
ARABICON ("arabicon") Copyright (c) 2006 By Alexey Kuleshov. <br>
</sub>

<sub>
This program is released under the GPL v2 with the additional exemption
that compiling, linking, and/or using OpenSSL is allowed. You may
provide binary packages linked to the OpenSSL libraries, provided that
all other requirements of the GPL are met.
See file COPYING for details.
</sub>
